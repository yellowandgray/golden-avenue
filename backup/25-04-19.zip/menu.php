<div id="nav">
    <div class="topbar">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
    <!--                <p class="pull-left hidden-xs"><span>Welcome to Golden Avenue</span></p> -->
                    <p class="pull-right">
    <!--                    <a href=""><i class="fa fa-facebook"></i></a>
                        <a href=""><i class="fa fa-twitter"></i></a>
                        <a href=""><i class="fa fa-linkedin"></i></a>
                        <a href=""><i class="fa fa-pinterest"></i></a>
                        <a href=""><i class="fa fa-google-plus"></i></a>&nbsp;-->
                        <i class="fa fa-phone"></i><a href="tel:+04 2668272">04 2668272</a>
                        <i class="fa fa-envelope-o"></i><a href="mailto:enquiry@goldenavenue.ae">enquiry@goldenavenue.ae</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- start header -->
    <header>
        <div class="navbar navbar-default navbar-static-top" >
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><img src="img/Logo-Golden-Avenue.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <!--                    <li class="active"><a href="index.html">Home</a></li> 
                                           <li class="dropdown">
                                                <a href="#" data-toggle="dropdown" class="dropdown-toggle">About Us <b class="caret"></b></a>
                                                <ul class="dropdown-menu">
                                                    <li><a href="about.html">Company</a></li>
                                                    <li><a href="#">Our Team</a></li>
                                                    <li><a href="#">News</a></li> 
                                                    <li><a href="#">Investors</a></li>
                                                </ul>
                                            </li> 
                                       <li><a href="#"></a></li>-->
                        <li class="<?php if ($page == 'services') {
    echo 'active';
} ?> dropdown">
                            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Services <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="it-health-check.php">IT & Network Health Checks</a></li>
                                <!--                            <li><a href="network-health-check.php">NETWORK HEALTH CHECKS</a></li>-->
                                <li><a href="business-continuity.php">Business Continuity</a></li> 
                                <li><a href="it-security.php">IT Security</a></li>
                                <li><a href="consulting-service.php">Consulting Services</a></li>
                                <li><a href="cloud-migration.php">Cloud Migration</a></li>
                                <li><a href="cyber-security.php">Cyber Security Awareness</a></li>
                                <li><a href="it_procurement.php">IT Procurement Services</a></li>
                            </ul>
                        </li>
                        <li class="<?php if ($page == 'amc-contract') {
    echo 'active';
} ?>"><a href="amc-contract.php">Annual Maintenance Contracts</a></li>
                        <li class="<?php if ($page == 'products') {
    echo 'active';
} ?>"><a href="product.php">Products</a></li>
                        <li class="<?php if ($page == 'blog') {
    echo 'active';
    } ?>"><a href="blog.php">Blog</a></li>
                        <li class="<?php if ($page == 'why-us') {
    echo 'active';
} ?>"><a href="why-us.php">Why Us</a></li>
                        <li class="<?php if ($page == 'contact') {
    echo 'active';
} ?>"><a href="contacts.php">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <marquee>IT & &nbsp;&nbsp;Network Health Checks,&nbsp;&nbsp; Business Continuity,&nbsp;&nbsp; IT Security,&nbsp;&nbsp; Consulting Services and Cloud Migration &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;For&nbsp;&nbsp; <blink style="color: black"><strong>FREE</strong></blink>&nbsp;&nbsp; IT Health Check&nbsp;&nbsp; Call&nbsp;&nbsp;: 04 2668272</marquee>
</div>