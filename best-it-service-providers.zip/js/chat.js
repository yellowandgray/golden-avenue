function openPopup() {
    $(".chat-popup-section").fadeIn(2000);
    document.getElementById("myForm").style.display = "block";
}

function closePopup() {
    document.getElementById("myForm").style.display = "none";
}
function closePopup() {
    document.getElementById("myForm").style.display = "none";
}