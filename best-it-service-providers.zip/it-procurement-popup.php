<div class="side-widget open">
<!--    <div class="inner">-->
<a href="it-procurement.php" class="btn btn-blue productCheckout" id="get-started"><i class="fa fa-play-circle video"></i>&nbsp;&nbsp; IT&nbsp;&nbsp; PROCUREMENT&nbsp;&nbsp; GUIDE</a>
<!--    </div>-->
</div>
<!--<div id="popup-container">
    <div id="popup-window">
        <div class="modal-content">
            <button type="button" class="close margin-top--20" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>  
            <a href="#" class="your-class"></a>
            <div>
                <div class="row margin-bottom-0 text-center" id="video_container">
                    <iframe src="https://www.youtube.com/embed/0p3787JiFgQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>-->