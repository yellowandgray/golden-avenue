<div id="sub-footer">
    <div class="container">
        <div class="row" style="padding-bottom: 20px;">
            <div class="col-sm-12">
                <div class="copyright">
                    <p>
                        <span>Our Services : <a href="" >IT & Network Health Checks</a> | <a href="" >Business Continuity</a> | <a href="" >IT Security</a> | <a href="" >Consulting Services</a> | <a href="" >Cloud Migration</a> | <a href="" >Cyber Security Awareness</a>.</span>
                    </p>
                    <p>
                        <span>Our Contact : Golden Avenue, P.O.Box-122041, Dubai, U.A.E. | <a href="tel:+971 4 266 8272">+971 4 266 8272</a> | <a href="+971 4 271 3404">+971 4 271 3404</a> | <a href="mailto:enquiry@goldenavenue.ae">enquiry@goldenavenue.ae.</a></span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.fancybox.pack.js"></script>
<script src="../js/jquery.fancybox-media.js"></script>  
<script src="../js/jquery.flexslider.js"></script>
<script src="../js/animate.js"></script>
<!-- Vendor Scripts -->
<script src="../js/modernizr.custom.js"></script>
<script src="../js/jquery.isotope.min.js"></script>
<script src="../js/jquery.magnific-popup.min.js"></script>
<script src="js/contact-form.js" type="text/javascript"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script> 
<script src="../js/common.js" type="text/javascript"></script>
<script src="../js/chat.js" type="text/javascript"></script>
<script src="../js/wow/wow.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script>
<script>
    wow = new WOW(
            {
                animateClass: 'animated',
                offset: 100,
                callback: function (box) {
                    console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
                }
            }
    );
    wow.init();
    document.getElementById('moar').onclick = function () {
        var section = document.createElement('section');
        section.className = 'section--purple wow fadeInDown';
        this.parentNode.insertBefore(section, this);
    };
</script>