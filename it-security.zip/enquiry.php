<div class="box-shadow-2">
    <form id="enquiry">
        <h3 class="text-center bold">Enquiry</h3>
        <input class="form-control" name="name" id="first_name" placeholder="Name *" required>
        <br>
        <input class="form-control" name="email" id="email" placeholder="Your Email *">
        <br>
        <input class="form-control" name="phone" placeholder="Phone *" id="phone">
        <br>
        <input class="form-control" name="subject" placeholder="Subject" id="subject">
        <br>
        <textarea class="form-control" name="subject" rows="4" placeholder="Comments" id="comments"></textarea>

        <br>
        <center>
            <input type="submit" class="btn btn-blue" value="Submit">
        </center>
    </form>
</div>