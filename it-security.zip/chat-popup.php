<button class="chat-popup-button" onclick="openPopup()"><i class="fa fa-comments fa-3x" aria-hidden="true"></i></button>

<div class="chat-popup-section" id="myForm">
    <div class="chat-bg-css"></div>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closePopup()" style="margin-top: -22px"><span aria-hidden="true">×</span></button>
    <form action="#" class="chat-popup-form-container">
        <div><img src="img/person-chat.png" class="img-responsive" style="width: 20%;" /> Hi, How can i help you?</div>
        <div class="textarea-1"></div>
        <div class="box-chat-shadow">
            <input type="text" class="chat-input" placeholder="Type message.." />
            <div class="floatright"><button class="btn"><i class="fa fa-share-square"></i></button></div>
        </div>
    </form>
</div>