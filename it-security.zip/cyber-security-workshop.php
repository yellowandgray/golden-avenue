<div class="cyber-security-bg">
    <a href="cyber-security.php"><h4 class="text-center bold">Cyber Security Awareness Workshop at your Premise for AED 1</h4></a>
    <a href="cyber-security.php"><img src="img/golden-cyber.jpg" class="img-responsive img-width" /></a>
    <p>- Protect your business <br/>- Make employees your active defense against cyber threats </p>
    <hr class="hr1"> 
    <a href="cyber-security.php" type="buttton" class="btn-custom">See More</a>
<!--                                        <p class="font-size-12 bold">Date: &nbsp;&nbsp;&nbsp; January 01, 2019</p>-->
</div>